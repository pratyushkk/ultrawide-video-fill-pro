"use strict";
(() => {
  // src/utils/fillCalculator.ts
  function calculateFillTransform(input) {
    const { videoWidth, videoHeight, containerWidth, containerHeight } = input;
    if (videoWidth <= 0 || videoHeight <= 0 || containerWidth <= 0 || containerHeight <= 0) {
      return {
        scale: 1,
        translateX: 0,
        translateY: 0,
        videoAspectRatio: 0,
        targetAspectRatio: 0,
        cropLeft: 0,
        cropRight: 0,
        cropTop: 0,
        cropBottom: 0
      };
    }
    const videoAspectRatio = videoWidth / videoHeight;
    const targetAspectRatio = containerWidth / containerHeight;
    let scale;
    if (videoAspectRatio < targetAspectRatio) {
      scale = targetAspectRatio / videoAspectRatio;
    } else {
      scale = videoAspectRatio / targetAspectRatio;
    }
    let cropLeft = 0;
    let cropRight = 0;
    let cropTop = 0;
    let cropBottom = 0;
    if (videoAspectRatio < targetAspectRatio) {
      const excessHeight = containerHeight * (scale - 1);
      cropTop = excessHeight / 2;
      cropBottom = excessHeight / 2;
    } else if (videoAspectRatio > targetAspectRatio) {
      const excessWidth = containerWidth * (scale - 1);
      cropLeft = excessWidth / 2;
      cropRight = excessWidth / 2;
    }
    return {
      scale,
      translateX: 0,
      // Centered, no translate needed with CSS transform-origin center
      translateY: 0,
      videoAspectRatio,
      targetAspectRatio,
      cropLeft,
      cropRight,
      cropTop,
      cropBottom
    };
  }
  function calculateAdjustedScale(baseScale, adjustmentPercent) {
    return baseScale * (1 + adjustmentPercent / 100);
  }

  // src/gpu/GPUCapabilities.ts
  var cachedCapabilities = null;
  var GPUCapabilities = class {
    /**
     * Detect system GPU and display capabilities.
     * Caches result to avoid redundant canvas/device creation.
     */
    static async detect(forceRefresh = false) {
      if (cachedCapabilities && !forceRefresh) {
        return cachedCapabilities;
      }
      let webgpuSupported = false;
      let webgl2Supported = false;
      let hdrDisplaySupported = false;
      try {
        if (typeof navigator !== "undefined" && "gpu" in navigator && navigator.gpu) {
          const adapter = await navigator.gpu.requestAdapter({
            powerPreference: "high-performance"
          });
          if (adapter) {
            const device = await adapter.requestDevice();
            if (device) {
              webgpuSupported = true;
              if (typeof device.destroy === "function") {
                device.destroy();
              }
            }
          }
        }
      } catch (e) {
        console.warn("[UWVF-GPU] WebGPU detection failed or not supported:", e);
        webgpuSupported = false;
      }
      try {
        if (typeof document !== "undefined") {
          const testCanvas = document.createElement("canvas");
          testCanvas.width = 1;
          testCanvas.height = 1;
          const gl = testCanvas.getContext("webgl2", {
            powerPreference: "high-performance",
            failIfMajorPerformanceCaveat: false
          });
          if (gl) {
            webgl2Supported = true;
            const loseContext = gl.getExtension("WEBGL_lose_context");
            if (loseContext) {
              loseContext.loseContext();
            }
          }
        }
      } catch (e) {
        console.warn("[UWVF-GPU] WebGL2 detection failed:", e);
        webgl2Supported = false;
      }
      try {
        if (typeof window !== "undefined" && typeof window.matchMedia === "function") {
          const highDynamicRange = window.matchMedia("(dynamic-range: high)").matches;
          const wideGamutP3 = window.matchMedia("(color-gamut: p3)").matches;
          hdrDisplaySupported = highDynamicRange || wideGamutP3;
        }
      } catch (e) {
        console.warn("[UWVF-GPU] HDR display query failed:", e);
        hdrDisplaySupported = false;
      }
      let preferredBackend = "unavailable";
      if (webgpuSupported) {
        preferredBackend = "webgpu";
      } else if (webgl2Supported) {
        preferredBackend = "webgl2";
      }
      cachedCapabilities = {
        webgpuSupported,
        webgl2Supported,
        hdrDisplaySupported,
        preferredBackend
      };
      return cachedCapabilities;
    }
    /**
     * Synchronous quick check based on cached or basic API presence.
     */
    static isAnyGPUSupported() {
      if (cachedCapabilities) {
        return cachedCapabilities.webgpuSupported || cachedCapabilities.webgl2Supported;
      }
      return typeof navigator !== "undefined" && "gpu" in navigator || typeof WebGL2RenderingContext !== "undefined";
    }
  };

  // src/gpu/PerformanceMonitor.ts
  var PerformanceMonitor = class {
    lastFrameTimestamp = 0;
    frameCount = 0;
    lastFpsCalcTime = 0;
    currentFps = 0;
    lastFrameDurationMs = 0;
    avgFrameDurationMs = 0;
    droppedFrames = 0;
    expectedIntervalMs = 1e3 / 30;
    // default 30fps video
    backendType = "bypassed";
    resolution = "0x0";
    activePasses = 0;
    constructor() {
      this.reset();
    }
    reset() {
      this.lastFrameTimestamp = 0;
      this.frameCount = 0;
      this.lastFpsCalcTime = performance.now();
      this.currentFps = 0;
      this.lastFrameDurationMs = 0;
      this.avgFrameDurationMs = 0;
      this.droppedFrames = 0;
      this.activePasses = 0;
    }
    setBackend(backend) {
      this.backendType = backend;
    }
    setResolution(width, height) {
      this.resolution = `${width}x${height}`;
    }
    setExpectedFps(fps) {
      if (fps > 10 && fps <= 120) {
        this.expectedIntervalMs = 1e3 / fps;
      }
    }
    setActivePasses(passes) {
      this.activePasses = passes;
    }
    recordFrameStart() {
      return performance.now();
    }
    recordFrameEnd(startTime) {
      const now = performance.now();
      this.lastFrameDurationMs = Math.max(0, now - startTime);
      if (this.avgFrameDurationMs === 0) {
        this.avgFrameDurationMs = this.lastFrameDurationMs;
      } else {
        this.avgFrameDurationMs = this.avgFrameDurationMs * 0.9 + this.lastFrameDurationMs * 0.1;
      }
      if (this.lastFrameTimestamp > 0) {
        const delta = now - this.lastFrameTimestamp;
        if (delta > this.expectedIntervalMs * 1.85) {
          const missed = Math.floor(delta / this.expectedIntervalMs) - 1;
          this.droppedFrames += Math.max(1, missed);
        }
      }
      this.lastFrameTimestamp = now;
      this.frameCount++;
      const elapsed = now - this.lastFpsCalcTime;
      if (elapsed >= 500) {
        this.currentFps = Math.round(this.frameCount * 1e3 / elapsed);
        this.frameCount = 0;
        this.lastFpsCalcTime = now;
      }
    }
    getDiagnostics(isSupported) {
      return {
        backend: this.backendType,
        isSupported,
        fps: this.currentFps,
        frameTimeMs: Math.round(this.avgFrameDurationMs * 100) / 100,
        droppedFrames: this.droppedFrames,
        resolution: this.resolution,
        activePasses: this.activePasses
      };
    }
    getSuggestedQuality() {
      if (this.avgFrameDurationMs > 14) {
        return 0;
      }
      if (this.avgFrameDurationMs > 7) {
        return 1;
      }
      return 2;
    }
  };

  // src/gpu/shaders/wgsl.ts
  var WGSL_SHADER_SOURCE = (
    /* wgsl */
    `
struct Uniforms {
  sharpness: f32,    // 0.0 to 1.0
  hdrBoost: f32,     // 0.0 to 1.0
  texWidth: f32,
  texHeight: f32,
  quality: u32,      // 0: fast, 1: balanced, 2: quality
  abMode: u32,       // 0: full screen, 1: split-screen comparison
  pad1: u32,
  pad2: u32,
};

@group(0) @binding(0) var videoTexture: texture_external;
@group(0) @binding(1) var videoSampler: sampler;
@group(0) @binding(2) var<uniform> uniforms: Uniforms;

struct VertexOutput {
  @builtin(position) position: vec4<f32>,
  @location(0) uv: vec2<f32>,
};

// Fullscreen triangle covering [-1, 1] clip space
@vertex
fn vs_main(@builtin(vertex_index) vertexIndex: u32) -> VertexOutput {
  var out: VertexOutput;
  // Positions for full-screen triangle:
  // 0: (-1, -1), 1: (3, -1), 2: (-1, 3)
  let x = f32((vertexIndex << 1u) & 2u) * 2.0 - 1.0;
  let y = f32(vertexIndex & 2u) * 2.0 - 1.0;
  
  out.position = vec4<f32>(x, y, 0.0, 1.0);
  // UV coordinates: (0, 1) -> (2, 1) -> (0, -1) mapped to [0, 1]
  out.uv = vec2<f32>(x * 0.5 + 0.5, 0.5 - y * 0.5);
  return out;
}

// Rec. 709 Luminance
fn getLuminance(rgb: vec3<f32>) -> f32 {
  return dot(rgb, vec3<f32>(0.2126, 0.7152, 0.0722));
}

// Soft S-curve for midtone contrast expansion
fn sCurve(x: f32) -> f32 {
  return x * x * (3.0 - 2.0 * x);
}

@fragment
fn fs_main(in: VertexOutput) -> @location(0) vec4<f32> {
  let uv = in.uv;

  // Split-screen A/B mode check
  if (uniforms.abMode == 1u) {
    let splitX = 0.5;
    // Draw 2px vertical dividing line
    let pixelDist = abs(uv.x - splitX) * uniforms.texWidth;
    if (pixelDist < 1.0) {
      return vec4<f32>(1.0, 1.0, 1.0, 1.0);
    }
    // Left half: bypass original video
    if (uv.x < splitX) {
      return textureSampleBaseClampToEdge(videoTexture, videoSampler, uv);
    }
  }

  // Bypass if both effects are zero
  if (uniforms.sharpness <= 0.001 && uniforms.hdrBoost <= 0.001) {
    return textureSampleBaseClampToEdge(videoTexture, videoSampler, uv);
  }

  let center = textureSampleBaseClampToEdge(videoTexture, videoSampler, uv).rgb;
  let lumC = getLuminance(center);

  // Compute pixel step for texture sampling
  let dx = 1.0 / max(uniforms.texWidth, 1.0);
  let dy = 1.0 / max(uniforms.texHeight, 1.0);

  // Cross neighbor samples
  let sampleTop   = textureSampleBaseClampToEdge(videoTexture, videoSampler, uv + vec2<f32>(0.0, -dy)).rgb;
  let sampleBottom= textureSampleBaseClampToEdge(videoTexture, videoSampler, uv + vec2<f32>(0.0, dy)).rgb;
  let sampleLeft  = textureSampleBaseClampToEdge(videoTexture, videoSampler, uv + vec2<f32>(-dx, 0.0)).rgb;
  let sampleRight = textureSampleBaseClampToEdge(videoTexture, videoSampler, uv + vec2<f32>(dx, 0.0)).rgb;

  let lumTop    = getLuminance(sampleTop);
  let lumBottom = getLuminance(sampleBottom);
  let lumLeft   = getLuminance(sampleLeft);
  let lumRight  = getLuminance(sampleRight);

  var lumMin = min(lumC, min(min(lumTop, lumBottom), min(lumLeft, lumRight)));
  var lumMax = max(lumC, max(max(lumTop, lumBottom), max(lumLeft, lumRight)));
  var lumBlur = (lumTop + lumBottom + lumLeft + lumRight) * 0.25;

  // Higher quality: include diagonal corner samples
  if (uniforms.quality >= 1u) {
    let sampleTL = textureSampleBaseClampToEdge(videoTexture, videoSampler, uv + vec2<f32>(-dx, -dy)).rgb;
    let sampleTR = textureSampleBaseClampToEdge(videoTexture, videoSampler, uv + vec2<f32>(dx, -dy)).rgb;
    let sampleBL = textureSampleBaseClampToEdge(videoTexture, videoSampler, uv + vec2<f32>(-dx, dy)).rgb;
    let sampleBR = textureSampleBaseClampToEdge(videoTexture, videoSampler, uv + vec2<f32>(dx, dy)).rgb;

    let lumTL = getLuminance(sampleTL);
    let lumTR = getLuminance(sampleTR);
    let lumBL = getLuminance(sampleBL);
    let lumBR = getLuminance(sampleBR);

    lumMin = min(lumMin, min(min(lumTL, lumTR), min(lumBL, lumBR)));
    lumMax = max(lumMax, max(max(lumTL, lumTR), max(lumBL, lumBR)));
    // Weighted 3x3 Gaussian-like average
    lumBlur = lumBlur * 0.6 + (lumTL + lumTR + lumBL + lumBR) * 0.1;
  }

  // \u2500\u2500\u2500 1. ADAPTIVE SHARPNESS \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
  var processedLum = lumC;

  if (uniforms.sharpness > 0.001) {
    let detail = lumC - lumBlur;

    // Noise coring threshold: suppress fine noise / grain in flat or dark areas
    let coringThreshold = 0.008 + (1.0 - smoothstep(0.02, 0.15, lumC)) * 0.012;
    let detailSign = sign(detail);
    let detailAbs = abs(detail);
    let coredDetail = detailSign * max(0.0, detailAbs - coringThreshold);

    // Dynamic detail gain: maps slider 0..1 to 0..2.2x strength
    let sharpnessFactor = uniforms.sharpness * 2.2;
    let sharpLum = lumC + coredDetail * sharpnessFactor;

    // Halo & ringing prevention: clamp to local neighborhood range with gentle overshooting allowance
    let haloSlack = (lumMax - lumMin) * 0.15;
    processedLum = clamp(sharpLum, max(0.0, lumMin - haloSlack), min(1.0, lumMax + haloSlack));
  }

  // \u2500\u2500\u2500 2. HDR DYNAMIC RANGE BOOST \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
  if (uniforms.hdrBoost > 0.001) {
    let hdrAmount = uniforms.hdrBoost;

    // A. Controlled Shadow Preservation:
    // Protect deep blacks (lum < 0.04) from washing out into gray
    let shadowMask = smoothstep(0.005, 0.08, processedLum);

    // B. Midtone Contrast Expansion:
    // S-curve boosts midtone punch while maintaining smooth gradients
    let curvedLum = sCurve(processedLum);
    var boostedLum = mix(processedLum, curvedLum, hdrAmount * 0.45);

    // C. Highlight Reconstruction & Shoulder Roll-off (Extended Reinhard Tone Curve):
    // White point ceiling
    let whitePoint = 1.35;
    let extendedReinhard = (boostedLum * (1.0 + boostedLum / (whitePoint * whitePoint))) / (1.0 + boostedLum);
    
    // Blend expanded dynamic range based on HDR intensity
    boostedLum = mix(boostedLum, extendedReinhard, hdrAmount * shadowMask);
    processedLum = clamp(boostedLum, 0.0, 1.0);
  }

  // \u2500\u2500\u2500 3. COLOR RECONSTRUCTION & CHROMINANCE BOOST \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
  let lumRatio = processedLum / max(lumC, 0.0001);
  var outColor = center * lumRatio;

  // Gamut & Saturation Enhancement:
  // When HDR boost is applied, slightly enhance saturation to match wide color gamut presentation
  if (uniforms.hdrBoost > 0.001) {
    let saturationBoost = 1.0 + uniforms.hdrBoost * 0.32;
    outColor = mix(vec3<f32>(processedLum), outColor, saturationBoost);
  }

  // Final safety clamp
  return vec4<f32>(clamp(outColor, vec3<f32>(0.0), vec3<f32>(1.0)), 1.0);
}
`
  );

  // src/gpu/WebGPUBackend.ts
  var WebGPUBackend = class {
    type = "webgpu";
    canvas = null;
    context = null;
    device = null;
    pipeline = null;
    uniformBuffer = null;
    sampler = null;
    bindGroupLayout = null;
    uniformFloatArray = new Float32Array(8);
    uniformUintArray = new Uint32Array(this.uniformFloatArray.buffer);
    initialized = false;
    onDeviceLostCallback = null;
    constructor(onDeviceLost) {
      this.onDeviceLostCallback = onDeviceLost || null;
    }
    isInitialized() {
      return this.initialized && this.device !== null;
    }
    async initialize(canvas) {
      try {
        this.canvas = canvas;
        if (typeof navigator === "undefined" || !("gpu" in navigator) || !navigator.gpu) {
          return false;
        }
        const adapter = await navigator.gpu.requestAdapter({
          powerPreference: "high-performance"
        });
        if (!adapter) {
          console.warn("[UWVF-WebGPU] No suitable GPU adapter found");
          return false;
        }
        const device = await adapter.requestDevice();
        if (!device) {
          console.warn("[UWVF-WebGPU] Failed to create GPU device");
          return false;
        }
        this.device = device;
        device.lost.then((info) => {
          console.warn(`[UWVF-WebGPU] GPU Device was lost: ${info?.message || info?.reason}`);
          this.initialized = false;
          if (this.onDeviceLostCallback) {
            this.onDeviceLostCallback();
          }
        }).catch(() => {
        });
        const ctx = canvas.getContext("webgpu");
        if (!ctx) {
          console.warn("[UWVF-WebGPU] Failed to get webgpu context on canvas");
          return false;
        }
        this.context = ctx;
        const presentationFormat = navigator.gpu.getPreferredCanvasFormat();
        this.context.configure({
          device,
          format: presentationFormat,
          alphaMode: "opaque"
        });
        const shaderModule = device.createShaderModule({
          code: WGSL_SHADER_SOURCE
        });
        this.sampler = device.createSampler({
          magFilter: "linear",
          minFilter: "linear",
          addressModeU: "clamp-to-edge",
          addressModeV: "clamp-to-edge"
        });
        this.uniformBuffer = device.createBuffer({
          size: 32,
          usage: 64 | 8
          // GPUBufferUsage.UNIFORM (0x0040) | GPUBufferUsage.COPY_DST (0x0008)
        });
        this.bindGroupLayout = device.createBindGroupLayout({
          entries: [
            {
              binding: 0,
              visibility: 2,
              // GPUShaderStage.FRAGMENT
              externalTexture: {}
            },
            {
              binding: 1,
              visibility: 2,
              sampler: { type: "filtering" }
            },
            {
              binding: 2,
              visibility: 2,
              buffer: { type: "uniform" }
            }
          ]
        });
        const pipelineLayout = device.createPipelineLayout({
          bindGroupLayouts: [this.bindGroupLayout]
        });
        this.pipeline = device.createRenderPipeline({
          layout: pipelineLayout,
          vertex: {
            module: shaderModule,
            entryPoint: "vs_main"
          },
          fragment: {
            module: shaderModule,
            entryPoint: "fs_main",
            targets: [{ format: presentationFormat }]
          },
          primitive: {
            topology: "triangle-list"
          }
        });
        this.initialized = true;
        return true;
      } catch (e) {
        console.error("[UWVF-WebGPU] Initialization error:", e);
        this.initialized = false;
        return false;
      }
    }
    updateUniforms(uniforms) {
      if (!this.device || !this.uniformBuffer) return;
      this.uniformFloatArray[0] = uniforms.sharpness;
      this.uniformFloatArray[1] = uniforms.hdrBoost;
      this.uniformFloatArray[2] = uniforms.texWidth;
      this.uniformFloatArray[3] = uniforms.texHeight;
      this.uniformUintArray[4] = uniforms.quality;
      this.uniformUintArray[5] = uniforms.abMode;
      this.uniformUintArray[6] = 0;
      this.uniformUintArray[7] = 0;
      this.device.queue.writeBuffer(this.uniformBuffer, 0, this.uniformFloatArray.buffer);
    }
    render(video, uniforms) {
      if (!this.initialized || !this.device || !this.context || !this.pipeline) {
        return;
      }
      try {
        this.updateUniforms(uniforms);
        const externalTexture = this.device.importExternalTexture({
          source: video
        });
        const bindGroup = this.device.createBindGroup({
          layout: this.bindGroupLayout,
          entries: [
            { binding: 0, resource: externalTexture },
            { binding: 1, resource: this.sampler },
            { binding: 2, resource: { buffer: this.uniformBuffer } }
          ]
        });
        const commandEncoder = this.device.createCommandEncoder();
        const currentTextureView = this.context.getCurrentTexture().createView();
        const renderPass = commandEncoder.beginRenderPass({
          colorAttachments: [
            {
              view: currentTextureView,
              clearValue: { r: 0, g: 0, b: 0, a: 1 },
              loadOp: "clear",
              storeOp: "store"
            }
          ]
        });
        renderPass.setPipeline(this.pipeline);
        renderPass.setBindGroup(0, bindGroup);
        renderPass.draw(3, 1, 0, 0);
        renderPass.end();
        this.device.queue.submit([commandEncoder.finish()]);
      } catch (e) {
        console.warn("[UWVF-WebGPU] Render frame error:", e);
      }
    }
    resize(width, height) {
      if (!this.canvas) return;
      if (this.canvas.width !== width || this.canvas.height !== height) {
        this.canvas.width = width;
        this.canvas.height = height;
      }
    }
    destroy() {
      this.initialized = false;
      if (this.device) {
        try {
          if (typeof this.device.destroy === "function") {
            this.device.destroy();
          }
        } catch {
        }
        this.device = null;
      }
      this.context = null;
      this.pipeline = null;
      this.uniformBuffer = null;
      this.sampler = null;
      this.canvas = null;
    }
  };

  // src/gpu/shaders/glsl.ts
  var GLSL_VERTEX_SHADER = `#version 300 es
precision highp float;

layout(location = 0) in vec2 a_position;
out vec2 v_uv;

void main() {
  // a_position is in range [-1, 1]
  gl_Position = vec4(a_position, 0.0, 1.0);
  // UV in range [0, 1]
  v_uv = a_position * 0.5 + 0.5;
}
`;
  var GLSL_FRAGMENT_SHADER = `#version 300 es
precision highp float;

in vec2 v_uv;
out vec4 fragColor;

uniform sampler2D u_videoTexture;
uniform float u_sharpness;
uniform float u_hdrBoost;
uniform vec2 u_texSize;
uniform int u_quality;
uniform int u_abMode;

// Rec. 709 Luminance
float getLuminance(vec3 rgb) {
  return dot(rgb, vec3(0.2126, 0.7152, 0.0722));
}

// Soft S-curve for midtone contrast expansion
float sCurve(float x) {
  return x * x * (3.0 - 2.0 * x);
}

void main() {
  vec2 uv = v_uv;

  // Split-screen A/B mode check
  if (u_abMode == 1) {
    float splitX = 0.5;
    float pixelDist = abs(uv.x - splitX) * u_texSize.x;
    if (pixelDist < 1.0) {
      fragColor = vec4(1.0, 1.0, 1.0, 1.0);
      return;
    }
    // Left half: bypass original video
    if (uv.x < splitX) {
      fragColor = texture(u_videoTexture, uv);
      return;
    }
  }

  // Bypass check
  if (u_sharpness <= 0.001 && u_hdrBoost <= 0.001) {
    fragColor = texture(u_videoTexture, uv);
    return;
  }

  vec3 center = texture(u_videoTexture, uv).rgb;
  float lumC = getLuminance(center);

  vec2 step = 1.0 / max(u_texSize, vec2(1.0));

  // Cross neighbor samples
  vec3 sampleTop    = texture(u_videoTexture, uv + vec2(0.0, -step.y)).rgb;
  vec3 sampleBottom = texture(u_videoTexture, uv + vec2(0.0, step.y)).rgb;
  vec3 sampleLeft   = texture(u_videoTexture, uv + vec2(-step.x, 0.0)).rgb;
  vec3 sampleRight  = texture(u_videoTexture, uv + vec2(step.x, 0.0)).rgb;

  float lumTop    = getLuminance(sampleTop);
  float lumBottom = getLuminance(sampleBottom);
  float lumLeft   = getLuminance(sampleLeft);
  float lumRight  = getLuminance(sampleRight);

  float lumMin = min(lumC, min(min(lumTop, lumBottom), min(lumLeft, lumRight)));
  float lumMax = max(lumC, max(max(lumTop, lumBottom), max(lumLeft, lumRight)));
  float lumBlur = (lumTop + lumBottom + lumLeft + lumRight) * 0.25;

  if (u_quality >= 1) {
    vec3 sampleTL = texture(u_videoTexture, uv + vec2(-step.x, -step.y)).rgb;
    vec3 sampleTR = texture(u_videoTexture, uv + vec2(step.x, -step.y)).rgb;
    vec3 sampleBL = texture(u_videoTexture, uv + vec2(-step.x, step.y)).rgb;
    vec3 sampleBR = texture(u_videoTexture, uv + vec2(step.x, step.y)).rgb;

    float lumTL = getLuminance(sampleTL);
    float lumTR = getLuminance(sampleTR);
    float lumBL = getLuminance(sampleBL);
    float lumBR = getLuminance(sampleBR);

    lumMin = min(lumMin, min(min(lumTL, lumTR), min(lumBL, lumBR)));
    lumMax = max(lumMax, max(max(lumTL, lumTR), max(lumBL, lumBR)));
    lumBlur = lumBlur * 0.6 + (lumTL + lumTR + lumBL + lumBR) * 0.1;
  }

  // 1. Adaptive Sharpness
  float processedLum = lumC;
  if (u_sharpness > 0.001) {
    float detail = lumC - lumBlur;
    float coringThreshold = 0.008 + (1.0 - smoothstep(0.02, 0.15, lumC)) * 0.012;
    float detailSign = sign(detail);
    float detailAbs = abs(detail);
    float coredDetail = detailSign * max(0.0, detailAbs - coringThreshold);

    float sharpnessFactor = u_sharpness * 2.2;
    float sharpLum = lumC + coredDetail * sharpnessFactor;

    float haloSlack = (lumMax - lumMin) * 0.15;
    processedLum = clamp(sharpLum, max(0.0, lumMin - haloSlack), min(1.0, lumMax + haloSlack));
  }

  // 2. HDR Boost
  if (u_hdrBoost > 0.001) {
    float hdrAmount = u_hdrBoost;
    float shadowMask = smoothstep(0.005, 0.08, processedLum);

    float curvedLum = sCurve(processedLum);
    float boostedLum = mix(processedLum, curvedLum, hdrAmount * 0.45);

    float whitePoint = 1.35;
    float extendedReinhard = (boostedLum * (1.0 + boostedLum / (whitePoint * whitePoint))) / (1.0 + boostedLum);

    boostedLum = mix(boostedLum, extendedReinhard, hdrAmount * shadowMask);
    processedLum = clamp(boostedLum, 0.0, 1.0);
  }

  // 3. Color Reconstruction
  float lumRatio = processedLum / max(lumC, 0.0001);
  vec3 outColor = center * lumRatio;

  if (u_hdrBoost > 0.001) {
    float saturationBoost = 1.0 + u_hdrBoost * 0.32;
    outColor = mix(vec3(processedLum), outColor, saturationBoost);
  }

  fragColor = vec4(clamp(outColor, 0.0, 1.0), 1.0);
}
`;

  // src/gpu/WebGL2Backend.ts
  var WebGL2Backend = class {
    type = "webgl2";
    canvas = null;
    gl = null;
    program = null;
    texture = null;
    vao = null;
    quadBuffer = null;
    // Uniform locations
    uVideoTextureLoc = null;
    uSharpnessLoc = null;
    uHdrBoostLoc = null;
    uTexSizeLoc = null;
    uQualityLoc = null;
    uAbModeLoc = null;
    initialized = false;
    isInitialized() {
      return this.initialized && this.gl !== null;
    }
    async initialize(canvas) {
      try {
        this.canvas = canvas;
        const gl = canvas.getContext("webgl2", {
          alpha: false,
          desynchronized: true,
          powerPreference: "high-performance",
          preserveDrawingBuffer: false
        });
        if (!gl) {
          console.warn("[UWVF-WebGL2] WebGL2 not supported on canvas");
          return false;
        }
        this.gl = gl;
        const vertShader = this.compileShader(gl.VERTEX_SHADER, GLSL_VERTEX_SHADER);
        const fragShader = this.compileShader(gl.FRAGMENT_SHADER, GLSL_FRAGMENT_SHADER);
        if (!vertShader || !fragShader) {
          return false;
        }
        const program = gl.createProgram();
        if (!program) return false;
        gl.attachShader(program, vertShader);
        gl.attachShader(program, fragShader);
        gl.linkProgram(program);
        if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
          console.error("[UWVF-WebGL2] Program link error:", gl.getProgramInfoLog(program));
          return false;
        }
        this.program = program;
        this.uVideoTextureLoc = gl.getUniformLocation(program, "u_videoTexture");
        this.uSharpnessLoc = gl.getUniformLocation(program, "u_sharpness");
        this.uHdrBoostLoc = gl.getUniformLocation(program, "u_hdrBoost");
        this.uTexSizeLoc = gl.getUniformLocation(program, "u_texSize");
        this.uQualityLoc = gl.getUniformLocation(program, "u_quality");
        this.uAbModeLoc = gl.getUniformLocation(program, "u_abMode");
        this.vao = gl.createVertexArray();
        gl.bindVertexArray(this.vao);
        this.quadBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, this.quadBuffer);
        const quadVertices = new Float32Array([
          -1,
          -1,
          1,
          -1,
          -1,
          1,
          1,
          1
        ]);
        gl.bufferData(gl.ARRAY_BUFFER, quadVertices, gl.STATIC_DRAW);
        gl.enableVertexAttribArray(0);
        gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
        this.texture = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, this.texture);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
        this.initialized = true;
        return true;
      } catch (e) {
        console.error("[UWVF-WebGL2] Initialization error:", e);
        this.initialized = false;
        return false;
      }
    }
    compileShader(type, source) {
      if (!this.gl) return null;
      const shader = this.gl.createShader(type);
      if (!shader) return null;
      this.gl.shaderSource(shader, source);
      this.gl.compileShader(shader);
      if (!this.gl.getShaderParameter(shader, this.gl.COMPILE_STATUS)) {
        console.error("[UWVF-WebGL2] Shader compile error:", this.gl.getShaderInfoLog(shader));
        this.gl.deleteShader(shader);
        return null;
      }
      return shader;
    }
    updateUniforms(uniforms) {
      if (!this.gl || !this.program) return;
      this.gl.useProgram(this.program);
      if (this.uSharpnessLoc) this.gl.uniform1f(this.uSharpnessLoc, uniforms.sharpness);
      if (this.uHdrBoostLoc) this.gl.uniform1f(this.uHdrBoostLoc, uniforms.hdrBoost);
      if (this.uTexSizeLoc) this.gl.uniform2f(this.uTexSizeLoc, uniforms.texWidth, uniforms.texHeight);
      if (this.uQualityLoc) this.gl.uniform1i(this.uQualityLoc, uniforms.quality);
      if (this.uAbModeLoc) this.gl.uniform1i(this.uAbModeLoc, uniforms.abMode);
    }
    render(video, uniforms) {
      if (!this.initialized || !this.gl || !this.program || !this.texture || !this.vao) {
        return;
      }
      const gl = this.gl;
      try {
        gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight);
        gl.useProgram(this.program);
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, this.texture);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, video);
        if (this.uVideoTextureLoc) {
          gl.uniform1i(this.uVideoTextureLoc, 0);
        }
        this.updateUniforms(uniforms);
        gl.bindVertexArray(this.vao);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      } catch (e) {
        console.warn("[UWVF-WebGL2] Render error:", e);
      }
    }
    resize(width, height) {
      if (!this.canvas) return;
      if (this.canvas.width !== width || this.canvas.height !== height) {
        this.canvas.width = width;
        this.canvas.height = height;
      }
    }
    destroy() {
      this.initialized = false;
      if (this.gl) {
        if (this.texture) this.gl.deleteTexture(this.texture);
        if (this.quadBuffer) this.gl.deleteBuffer(this.quadBuffer);
        if (this.vao) this.gl.deleteVertexArray(this.vao);
        if (this.program) this.gl.deleteProgram(this.program);
      }
      this.gl = null;
      this.canvas = null;
    }
  };

  // src/gpu/VideoGPUProcessor.ts
  var VideoGPUProcessor = class {
    video = null;
    canvas = null;
    backend = null;
    monitor = new PerformanceMonitor();
    sharpness = 0;
    // 0 to 100
    hdrBoost = 0;
    // 0 to 100
    brightness = 100;
    // 0 to 200, 100 is normal
    qualityPreference = 1;
    // 0: low, 1: balanced, 2: quality
    abMode = 0;
    // 0: normal, 1: split-screen
    isRunning = false;
    isBypassed = true;
    useDirectCompositor = false;
    rVfcId = null;
    rafId = null;
    isSupported = false;
    activeBackendType = "bypassed";
    boundOnVideoFrame;
    boundOnPlay;
    boundOnPause;
    boundOnVisibilityChange;
    constructor() {
      this.boundOnVideoFrame = this.onFrame.bind(this);
      this.boundOnPlay = () => this.startLoop();
      this.boundOnPause = () => this.stopLoop();
      this.boundOnVisibilityChange = () => {
        if (document.hidden) {
          this.stopLoop();
        } else if (!this.isBypassed && !this.useDirectCompositor && this.video && !this.video.paused) {
          this.startLoop();
        }
      };
      document.addEventListener("visibilitychange", this.boundOnVisibilityChange);
    }
    /**
     * Detects if the current video stream uses Encrypted Media Extensions (Widevine DRM)
     * or is playing on a known DRM streaming service (JioCinema, Hotstar, Prime Video, Netflix, etc.)
     */
    isDRMProtected() {
      if (!this.video) return false;
      if (this.video.mediaKeys || this.video.webkitMediaKeys) {
        return true;
      }
      if (typeof window !== "undefined" && window.location) {
        const host = window.location.hostname.toLowerCase();
        if (host.includes("hotstar") || host.includes("primevideo") || host.includes("amazon.") || host.includes("netflix") || host.includes("jiocinema") || host.includes("disneyplus") || host.includes("hulu") || host.includes("hbomax") || host.includes("max.com") || host.includes("peacocktv") || host.includes("paramountplus") || host.includes("appletv") || host.includes("sonyliv") || host.includes("zee5")) {
          return true;
        }
      }
      return false;
    }
    async attach(video) {
      if (this.video === video && this.canvas) {
        return true;
      }
      this.detach();
      this.video = video;
      this.useDirectCompositor = this.isDRMProtected();
      const canvas = document.createElement("canvas");
      canvas.className = "uwvf-gpu-canvas";
      canvas.setAttribute("aria-hidden", "true");
      canvas.style.position = "absolute";
      canvas.style.pointerEvents = "none";
      canvas.style.zIndex = "1";
      canvas.style.display = "none";
      canvas.style.transformOrigin = "center center";
      if (video.parentElement) {
        video.parentElement.appendChild(canvas);
      } else {
        document.body.appendChild(canvas);
      }
      this.canvas = canvas;
      video.addEventListener("play", this.boundOnPlay);
      video.addEventListener("playing", this.boundOnPlay);
      video.addEventListener("pause", this.boundOnPause);
      video.addEventListener("ended", this.boundOnPause);
      if (this.useDirectCompositor) {
        this.isSupported = true;
        this.activeBackendType = "direct-gpu";
        this.monitor.setBackend("direct-gpu");
        this.applyDirectFilters();
        return true;
      }
      const success = await this.initBackend();
      this.syncCanvasLayout();
      if (!this.isBypassed && !video.paused) {
        this.startLoop();
      }
      return success;
    }
    async initBackend() {
      if (!this.canvas) return false;
      const caps = await GPUCapabilities.detect();
      this.isSupported = caps.webgpuSupported || caps.webgl2Supported;
      if (!this.isSupported) {
        this.activeBackendType = "unavailable";
        this.monitor.setBackend("unavailable");
        return false;
      }
      if (caps.webgpuSupported) {
        const webgpu = new WebGPUBackend(() => this.handleDeviceLost());
        const ok = await webgpu.initialize(this.canvas);
        if (ok) {
          this.backend = webgpu;
          this.activeBackendType = "webgpu";
          this.monitor.setBackend("webgpu");
          return true;
        }
      }
      if (caps.webgl2Supported) {
        const webgl2 = new WebGL2Backend();
        const ok = await webgl2.initialize(this.canvas);
        if (ok) {
          this.backend = webgl2;
          this.activeBackendType = "webgl2";
          this.monitor.setBackend("webgl2");
          return true;
        }
      }
      this.useDirectCompositor = true;
      this.activeBackendType = "direct-gpu";
      this.monitor.setBackend("direct-gpu");
      return true;
    }
    async handleDeviceLost() {
      console.warn("[UWVF-GPU] Device lost, attempting fallback recovery...");
      if (this.backend) {
        this.backend.destroy();
        this.backend = null;
      }
      if (this.canvas) {
        const webgl2 = new WebGL2Backend();
        const ok = await webgl2.initialize(this.canvas);
        if (ok) {
          this.backend = webgl2;
          this.activeBackendType = "webgl2";
          this.monitor.setBackend("webgl2");
          return;
        }
      }
      this.useDirectCompositor = true;
      this.activeBackendType = "direct-gpu";
      this.applyDirectFilters();
    }
    setEffects(sharpness, hdrBoost, brightness) {
      this.sharpness = Math.max(0, Math.min(100, sharpness));
      this.hdrBoost = Math.max(0, Math.min(100, hdrBoost));
      if (brightness !== void 0) {
        this.brightness = Math.max(0, Math.min(200, brightness));
      }
      if (this.isDRMProtected() && !this.useDirectCompositor) {
        this.useDirectCompositor = true;
        this.stopLoop();
        if (this.canvas) {
          this.canvas.style.display = "none";
        }
        this.activeBackendType = "direct-gpu";
        this.monitor.setBackend("direct-gpu");
      }
      const shouldBypass = this.sharpness === 0 && this.hdrBoost === 0 && this.brightness === 100;
      this.setBypassed(shouldBypass);
      this.applyCurrentFilters();
    }
    setBrightness(brightness) {
      this.brightness = Math.max(0, Math.min(200, brightness));
      const shouldBypass = this.sharpness === 0 && this.hdrBoost === 0 && this.brightness === 100;
      this.setBypassed(shouldBypass);
      this.applyCurrentFilters();
    }
    getBrightness() {
      return this.brightness;
    }
    applyCurrentFilters() {
      if (this.useDirectCompositor) {
        this.applyDirectFilters();
      } else {
        const userBright = (this.brightness / 100).toFixed(3);
        const filterStr = this.brightness !== 100 ? `brightness(${userBright})` : "";
        if (this.canvas) {
          this.canvas.style.filter = filterStr;
        }
        if (this.video) {
          this.video.style.filter = filterStr;
        }
        this.updateUniforms();
      }
    }
    setQuality(quality) {
      this.qualityPreference = Math.max(0, Math.min(2, quality));
      if (!this.useDirectCompositor) {
        this.updateUniforms();
      }
    }
    setSplitScreen(enabled) {
      this.abMode = enabled ? 1 : 0;
      if (!this.useDirectCompositor) {
        this.updateUniforms();
      }
    }
    setBypassed(bypass) {
      if (this.isBypassed === bypass) return;
      this.isBypassed = bypass;
      if (bypass) {
        this.stopLoop();
        if (this.canvas) {
          this.canvas.style.display = "none";
          this.canvas.style.filter = "";
        }
        if (this.video) {
          this.video.style.filter = "";
        }
        this.monitor.setBackend("bypassed");
      } else {
        if (this.useDirectCompositor) {
          if (this.canvas) {
            this.canvas.style.display = "none";
          }
          this.applyDirectFilters();
          this.monitor.setBackend("direct-gpu");
        } else {
          const needsShader = this.sharpness > 0 || this.hdrBoost > 0;
          if (this.canvas) {
            this.canvas.style.display = needsShader ? "block" : "none";
          }
          this.monitor.setBackend(needsShader ? this.backend ? this.backend.type : "unavailable" : "direct-gpu");
          if (needsShader && this.video && !this.video.paused) {
            this.startLoop();
          } else {
            this.stopLoop();
          }
        }
      }
    }
    /**
     * Ensures the dynamic SVG unsharp convolution filter definition is present in the DOM.
     */
    ensureSvgFilter() {
      if (document.getElementById("uwvf-svg-filters")) return;
      const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
      svg.id = "uwvf-svg-filters";
      svg.setAttribute("style", "position: absolute; width: 0; height: 0; pointer-events: none; overflow: hidden;");
      svg.setAttribute("aria-hidden", "true");
      svg.innerHTML = `
      <defs>
        <filter id="uwvf-sharpness-filter" x="-10%" y="-10%" width="120%" height="120%">
          <feConvolveMatrix id="uwvf-sharpness-matrix" order="3" preserveAlpha="true" kernelMatrix="0 0 0 0 1 0 0 0 0" />
        </filter>
      </defs>
    `;
      (document.body || document.documentElement).appendChild(svg);
    }
    /**
     * Applies GPU hardware-accelerated filters directly to the <video> element.
     * Works on 100% of websites including DRM-protected EME videos (Hotstar, Prime Video, Netflix)
     * with zero black screens and zero security errors.
     */
    applyDirectFilters() {
      if (!this.video) return;
      if (this.sharpness === 0 && this.hdrBoost === 0 && this.brightness === 100) {
        this.video.style.filter = "";
        return;
      }
      this.ensureSvgFilter();
      const filters = [];
      if (this.sharpness > 0) {
        const k = this.sharpness / 100 * 0.65;
        const center = (1 + 4 * k).toFixed(3);
        const edge = (-k).toFixed(3);
        const matrix = `0 ${edge} 0 ${edge} ${center} ${edge} 0 ${edge} 0`;
        const matrixEl = document.getElementById("uwvf-sharpness-matrix");
        if (matrixEl) {
          matrixEl.setAttribute("kernelMatrix", matrix);
        }
        filters.push('url("#uwvf-sharpness-filter")');
      }
      const userBright = this.brightness / 100;
      if (this.hdrBoost > 0) {
        const hdr = this.hdrBoost / 100;
        const contrast = (1 + hdr * 0.28).toFixed(3);
        const b = (userBright * (1 + hdr * 0.05)).toFixed(3);
        const saturate = (1 + hdr * 0.32).toFixed(3);
        filters.push(`contrast(${contrast}) brightness(${b}) saturate(${saturate})`);
      } else if (this.brightness !== 100) {
        filters.push(`brightness(${userBright.toFixed(3)})`);
      }
      this.video.style.filter = filters.join(" ");
    }
    syncCanvasLayout() {
      if (this.useDirectCompositor || !this.video || !this.canvas) return;
      const vWidth = this.video.videoWidth || this.video.clientWidth || 1920;
      const vHeight = this.video.videoHeight || this.video.clientHeight || 1080;
      if (this.canvas.width !== vWidth || this.canvas.height !== vHeight) {
        this.canvas.width = vWidth;
        this.canvas.height = vHeight;
        if (this.backend) {
          this.backend.resize(vWidth, vHeight);
        }
        this.monitor.setResolution(vWidth, vHeight);
      }
      const rect = this.video.getBoundingClientRect();
      const parentRect = this.video.parentElement?.getBoundingClientRect() || { left: 0, top: 0 };
      this.canvas.style.left = `${this.video.offsetLeft || rect.left - parentRect.left}px`;
      this.canvas.style.top = `${this.video.offsetTop || rect.top - parentRect.top}px`;
      this.canvas.style.width = `${this.video.clientWidth || rect.width}px`;
      this.canvas.style.height = `${this.video.clientHeight || rect.height}px`;
      this.canvas.style.transform = this.video.style.transform || "";
      this.canvas.style.transformOrigin = this.video.style.transformOrigin || "center center";
      this.canvas.style.transition = this.video.style.transition || "";
    }
    startLoop() {
      if (this.isRunning || this.isBypassed || this.useDirectCompositor || !this.video || !this.backend) {
        return;
      }
      this.isRunning = true;
      this.scheduleNextFrame();
    }
    stopLoop() {
      this.isRunning = false;
      if (this.rVfcId !== null && this.video && "cancelVideoFrameCallback" in this.video) {
        this.video.cancelVideoFrameCallback(this.rVfcId);
        this.rVfcId = null;
      }
      if (this.rafId !== null) {
        cancelAnimationFrame(this.rafId);
        this.rafId = null;
      }
    }
    scheduleNextFrame() {
      if (!this.isRunning || !this.video) return;
      if ("requestVideoFrameCallback" in this.video) {
        this.rVfcId = this.video.requestVideoFrameCallback(this.boundOnVideoFrame);
      } else {
        this.rafId = requestAnimationFrame(this.boundOnVideoFrame);
      }
    }
    onFrame(now) {
      if (!this.isRunning || this.isBypassed || this.useDirectCompositor || !this.video || !this.backend) {
        return;
      }
      this.syncCanvasLayout();
      const startTime = this.monitor.recordFrameStart();
      const uniforms = this.getUniformData();
      try {
        this.backend.render(this.video, uniforms);
      } catch (e) {
        console.warn("[UWVF-GPU] Canvas render failed (DRM or security constraint). Switching to Direct GPU mode:", e);
        this.useDirectCompositor = true;
        this.stopLoop();
        if (this.canvas) {
          this.canvas.style.display = "none";
        }
        this.activeBackendType = "direct-gpu";
        this.monitor.setBackend("direct-gpu");
        this.applyDirectFilters();
        return;
      }
      this.monitor.recordFrameEnd(startTime);
      this.scheduleNextFrame();
    }
    getUniformData() {
      const vWidth = this.video?.videoWidth || 1920;
      const vHeight = this.video?.videoHeight || 1080;
      let activePasses = 0;
      if (this.sharpness > 0) activePasses++;
      if (this.hdrBoost > 0) activePasses++;
      this.monitor.setActivePasses(activePasses);
      return {
        sharpness: this.sharpness / 100,
        hdrBoost: this.hdrBoost / 100,
        texWidth: vWidth,
        texHeight: vHeight,
        quality: this.qualityPreference,
        abMode: this.abMode
      };
    }
    updateUniforms() {
      if (this.backend) {
        this.backend.updateUniforms(this.getUniformData());
      }
    }
    getDiagnostics() {
      return this.monitor.getDiagnostics(this.isSupported);
    }
    getActiveBackend() {
      if (this.isBypassed) return "bypassed";
      return this.activeBackendType;
    }
    getSharpness() {
      return this.sharpness;
    }
    getHdrBoost() {
      return this.hdrBoost;
    }
    detach() {
      this.stopLoop();
      this.setBypassed(true);
      if (this.video) {
        this.video.removeEventListener("play", this.boundOnPlay);
        this.video.removeEventListener("playing", this.boundOnPlay);
        this.video.removeEventListener("pause", this.boundOnPause);
        this.video.removeEventListener("ended", this.boundOnPause);
        this.video.style.filter = "";
        this.video = null;
      }
      if (this.canvas) {
        this.canvas.remove();
        this.canvas = null;
      }
      if (this.backend) {
        this.backend.destroy();
        this.backend = null;
      }
      this.monitor.reset();
    }
    destroy() {
      document.removeEventListener("visibilitychange", this.boundOnVisibilityChange);
      this.detach();
    }
  };

  // src/content/index.ts
  (function() {
    if (window.__uwvf_injected) return;
    window.__uwvf_injected = true;
    const state = {
      videos: /* @__PURE__ */ new Set(),
      activeVideo: null,
      isTransformed: false,
      currentScale: 1,
      autoFillScale: 1,
      adjustment: 0,
      containerWidth: 0,
      containerHeight: 0,
      autoFillEnabled: false,
      originalStyles: /* @__PURE__ */ new WeakMap(),
      originalContainerStyles: /* @__PURE__ */ new WeakMap(),
      // Advanced
      posX: 0,
      posY: 0,
      rotation: 0,
      mirrorH: false,
      mirrorV: false,
      cinemaCrop: "off",
      // GPU Enhancements
      sharpness: 0,
      hdrBoost: 0,
      brightness: 100,
      aspectRatio: "auto",
      gpuProcessor: new VideoGPUProcessor(),
      resizeObserver: null,
      mutationObserver: null,
      lastUrl: location.href,
      urlCheckInterval: 0
    };
    function debounce(func, wait) {
      let timeout;
      return function(...args) {
        if (timeout) clearTimeout(timeout);
        timeout = setTimeout(() => {
          timeout = null;
          func.apply(this, args);
        }, wait);
      };
    }
    function scoreVideo(video) {
      let score = 0;
      if (!video.paused) score += 1e3;
      const rect = video.getBoundingClientRect();
      const isVisible = rect.width > 0 && rect.height > 0 && rect.top < window.innerHeight && rect.bottom > 0;
      if (isVisible) score += 500;
      score += rect.width * rect.height / 1e3;
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      const distFromCenter = Math.hypot(
        centerX - window.innerWidth / 2,
        centerY - window.innerHeight / 2
      );
      score -= distFromCenter / 10;
      return score;
    }
    const scanForVideos = debounce(() => {
      const videoElements = document.querySelectorAll("video");
      videoElements.forEach((v) => {
        if (!state.videos.has(v)) {
          state.videos.add(v);
          v.addEventListener("play", onVideoPlay);
          v.addEventListener("loadedmetadata", handleResize);
        }
      });
      state.videos.forEach((v) => {
        if (!document.body.contains(v)) {
          state.videos.delete(v);
          v.removeEventListener("play", onVideoPlay);
          v.removeEventListener("loadedmetadata", handleResize);
          if (state.activeVideo === v) {
            resetTransformation();
            state.gpuProcessor.detach();
            state.activeVideo = null;
          }
        }
      });
      selectBestVideo();
    }, 300);
    function selectBestVideo() {
      let bestVideo = null;
      let bestScore = -Infinity;
      state.videos.forEach((video) => {
        const score = scoreVideo(video);
        if (score > bestScore) {
          bestScore = score;
          bestVideo = video;
        }
      });
      if (bestVideo && bestVideo !== state.activeVideo) {
        if (state.activeVideo) {
          resetTransformation();
        }
        state.activeVideo = bestVideo;
        observeVideo(bestVideo);
        state.gpuProcessor.attach(bestVideo);
        state.gpuProcessor.setEffects(state.sharpness, state.hdrBoost, state.brightness);
      }
    }
    function getTargetDimensions(video) {
      if (document.fullscreenElement) {
        const fsEl = document.fullscreenElement;
        return { width: fsEl.clientWidth, height: fsEl.clientHeight, container: fsEl };
      }
      let container = video.parentElement;
      const vWidth = video.clientWidth || video.getBoundingClientRect().width;
      const vHeight = video.clientHeight || video.getBoundingClientRect().height;
      while (container && container !== document.body) {
        const style = window.getComputedStyle(container);
        const rect = container.getBoundingClientRect();
        if (rect.width >= vWidth * 0.85 && rect.height >= vHeight * 0.85) {
          if (style.overflow === "hidden" || style.position === "relative" || style.position === "absolute" || style.display === "flex" || style.display === "grid") {
            return { width: rect.width, height: rect.height, container };
          }
        }
        container = container.parentElement;
      }
      return { width: window.innerWidth, height: window.innerHeight, container: document.body };
    }
    function applyTransform() {
      if (!state.activeVideo) return;
      const video = state.activeVideo;
      try {
        const { width, height, container } = getTargetDimensions(video);
        state.containerWidth = width;
        state.containerHeight = height;
        if (!video.videoWidth || !video.videoHeight) return;
        let targetWidth = width;
        let targetHeight = height;
        if (state.aspectRatio && state.aspectRatio !== "auto") {
          let presetRatio = 0;
          if (state.aspectRatio === "21:9") presetRatio = 21 / 9;
          else if (state.aspectRatio === "32:9") presetRatio = 32 / 9;
          else if (state.aspectRatio === "16:9") presetRatio = 16 / 9;
          else if (state.aspectRatio === "16:10") presetRatio = 16 / 10;
          else if (state.aspectRatio === "18:9") presetRatio = 18 / 9;
          if (presetRatio > 0) {
            targetWidth = targetHeight * presetRatio;
          }
        }
        const fillInput = {
          videoWidth: video.videoWidth,
          videoHeight: video.videoHeight,
          containerWidth: targetWidth,
          containerHeight: targetHeight
        };
        const fillTransform = calculateFillTransform(fillInput);
        state.autoFillScale = fillTransform.scale;
        let cinemaMultiplier = 1;
        if (state.cinemaCrop === "low") cinemaMultiplier = 1.1;
        else if (state.cinemaCrop === "medium") cinemaMultiplier = 1.22;
        else if (state.cinemaCrop === "high") cinemaMultiplier = 1.333;
        state.currentScale = calculateAdjustedScale(fillTransform.scale * cinemaMultiplier, state.adjustment);
        if (!state.originalStyles.has(video)) {
          state.originalStyles.set(video, {
            transform: video.style.transform || "",
            transition: video.style.transition || ""
          });
        }
        if (container && container !== document.body && !state.originalContainerStyles.has(container)) {
          state.originalContainerStyles.set(container, {
            overflow: container.style.overflow || ""
          });
        }
        video.classList.add("uwvf-active");
        video.style.transition = "transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)";
        const mirrorScaleX = state.mirrorH ? -1 : 1;
        const mirrorScaleY = state.mirrorV ? -1 : 1;
        video.style.transform = `scale(${state.currentScale * mirrorScaleX}, ${state.currentScale * mirrorScaleY}) translate(${state.posX}px, ${state.posY}px) rotate(${state.rotation}deg)`;
        video.style.transformOrigin = "center center";
        if (container && container !== document.body) {
          container.classList.add("uwvf-container");
          container.style.overflow = "hidden";
        }
        state.isTransformed = true;
        state.gpuProcessor.syncCanvasLayout();
      } catch (e) {
        console.error("[UWVF] Error applying transform:", e);
      }
    }
    function resetTransformation() {
      if (!state.activeVideo) return;
      const video = state.activeVideo;
      video.classList.remove("uwvf-active");
      const origStyles = state.originalStyles.get(video);
      if (origStyles) {
        video.style.transform = origStyles.transform;
        video.style.transition = origStyles.transition;
      } else {
        video.style.transform = "";
        video.style.transition = "";
      }
      const { container } = getTargetDimensions(video);
      if (container && container !== document.body) {
        container.classList.remove("uwvf-container");
        const origContainerStyles = state.originalContainerStyles.get(container);
        if (origContainerStyles) {
          container.style.overflow = origContainerStyles.overflow;
        } else {
          container.style.overflow = "";
        }
      }
      state.isTransformed = false;
      state.currentScale = 1;
      state.gpuProcessor.syncCanvasLayout();
    }
    const handleResize = debounce(() => {
      if (state.isTransformed) {
        applyTransform();
      }
    }, 150);
    function observeVideo(video) {
      if (state.resizeObserver) {
        state.resizeObserver.disconnect();
      }
      state.resizeObserver = new ResizeObserver(handleResize);
      state.resizeObserver.observe(video);
      const { container } = getTargetDimensions(video);
      if (container) {
        state.resizeObserver.observe(container);
      }
    }
    function onVideoPlay(e) {
      if (state.autoFillEnabled && !state.isTransformed) {
        setTimeout(() => {
          applyTransform();
        }, 100);
      }
    }
    function setupObservers() {
      state.mutationObserver = new MutationObserver((mutations) => {
        let shouldScan = false;
        for (const mutation of mutations) {
          if (mutation.addedNodes.length || mutation.removedNodes.length) {
            shouldScan = true;
            break;
          }
        }
        if (shouldScan) scanForVideos();
      });
      state.mutationObserver.observe(document.body, {
        childList: true,
        subtree: true
      });
      window.addEventListener("resize", handleResize);
      document.addEventListener("fullscreenchange", handleResize);
      scanForVideos();
    }
    function setupSPASupport() {
      state.urlCheckInterval = setInterval(() => {
        if (location.href !== state.lastUrl) {
          state.lastUrl = location.href;
          scanForVideos();
        }
      }, 1e3);
      window.addEventListener("yt-navigate-finish", () => {
        scanForVideos();
      });
    }
    function getVideoStatus() {
      const videos = Array.from(state.videos).map((v, idx) => ({
        index: idx,
        width: v.clientWidth,
        height: v.clientHeight,
        naturalWidth: v.videoWidth,
        naturalHeight: v.videoHeight,
        playing: !v.paused,
        visible: v.getBoundingClientRect().width > 0,
        area: v.clientWidth * v.clientHeight,
        src: v.src || v.currentSrc,
        currentTime: v.currentTime,
        duration: v.duration
      }));
      const diag = state.gpuProcessor.getDiagnostics();
      return {
        detected: state.videos.size > 0,
        videoCount: state.videos.size,
        activeVideoIndex: state.activeVideo ? Array.from(state.videos).indexOf(state.activeVideo) : -1,
        videos,
        isTransformed: state.isTransformed,
        currentScale: state.currentScale,
        autoFillScale: state.autoFillScale,
        adjustment: state.adjustment,
        containerWidth: state.containerWidth || (state.activeVideo ? getTargetDimensions(state.activeVideo).width : 0),
        containerHeight: state.containerHeight || (state.activeVideo ? getTargetDimensions(state.activeVideo).height : 0),
        isFullscreen: !!document.fullscreenElement,
        autoFillEnabled: state.autoFillEnabled,
        posX: state.posX,
        posY: state.posY,
        rotation: state.rotation,
        mirrorH: state.mirrorH,
        mirrorV: state.mirrorV,
        cinemaCrop: state.cinemaCrop,
        sharpness: state.sharpness,
        hdrBoost: state.hdrBoost,
        brightness: state.brightness,
        aspectRatio: state.aspectRatio || "auto",
        gpuBackend: state.gpuProcessor.getActiveBackend(),
        gpuAvailable: diag.isSupported,
        gpuFps: diag.fps,
        gpuFrameTimeMs: diag.frameTimeMs,
        gpuDroppedFrames: diag.droppedFrames,
        gpuResolution: diag.resolution,
        isDrmProtected: state.gpuProcessor.isDRMProtected()
      };
    }
    function handleInternalMessage(message, sendResponse) {
      try {
        switch (message.type) {
          case "GET_VIDEO_STATUS":
            sendResponse(getVideoStatus());
            break;
          case "ZOOM_TO_FILL":
            applyTransform();
            sendResponse(getVideoStatus());
            break;
          case "RESET":
            resetTransformation();
            sendResponse(getVideoStatus());
            break;
          case "SET_ADJUSTMENT": {
            const adjPayload = message.payload;
            const adjValue = typeof adjPayload === "number" ? adjPayload : adjPayload && typeof adjPayload === "object" && "adjustment" in adjPayload ? adjPayload.adjustment ?? 0 : 0;
            state.adjustment = adjValue;
            state.isTransformed = true;
            applyTransform();
            sendResponse(getVideoStatus());
            break;
          }
          case "SET_ASPECT_RATIO": {
            const arPayload = message.payload;
            const arVal = typeof arPayload === "string" ? arPayload : arPayload && typeof arPayload === "object" && "aspectRatio" in arPayload ? arPayload.aspectRatio ?? "auto" : "auto";
            state.aspectRatio = arVal;
            state.isTransformed = true;
            applyTransform();
            sendResponse(getVideoStatus());
            break;
          }
          case "SET_BRIGHTNESS": {
            const bPayload = message.payload;
            const bVal = typeof bPayload === "number" ? bPayload : bPayload?.brightness ?? 100;
            state.brightness = bVal;
            state.gpuProcessor.setBrightness(bVal);
            sendResponse(getVideoStatus());
            break;
          }
          case "SET_GPU_EFFECTS": {
            const payload = message.payload;
            if (payload) {
              if (payload.sharpness !== void 0) state.sharpness = payload.sharpness;
              if (payload.hdrBoost !== void 0) state.hdrBoost = payload.hdrBoost;
              state.gpuProcessor.setEffects(state.sharpness, state.hdrBoost);
              if (payload.quality !== void 0) state.gpuProcessor.setQuality(payload.quality);
              if (payload.abMode !== void 0) state.gpuProcessor.setSplitScreen(payload.abMode);
            }
            sendResponse(getVideoStatus());
            break;
          }
          case "GET_GPU_DIAGNOSTICS": {
            sendResponse(state.gpuProcessor.getDiagnostics());
            break;
          }
          case "SET_ADVANCED":
            if (message.payload && typeof message.payload === "object") {
              const payload = message.payload;
              if (payload.posX !== void 0) state.posX = payload.posX;
              if (payload.posY !== void 0) state.posY = payload.posY;
              if (payload.rotation !== void 0) state.rotation = payload.rotation;
              if (payload.mirrorH !== void 0) state.mirrorH = payload.mirrorH;
              if (payload.mirrorV !== void 0) state.mirrorV = payload.mirrorV;
              if (payload.cinemaCrop !== void 0) state.cinemaCrop = payload.cinemaCrop;
              if (payload.sharpness !== void 0) {
                state.sharpness = payload.sharpness;
                state.gpuProcessor.setEffects(state.sharpness, state.hdrBoost);
              }
              if (payload.hdrBoost !== void 0) {
                state.hdrBoost = payload.hdrBoost;
                state.gpuProcessor.setEffects(state.sharpness, state.hdrBoost);
              }
              if (state.isTransformed) {
                applyTransform();
              }
            }
            sendResponse(getVideoStatus());
            break;
          case "TOGGLE_AUTO_FILL": {
            const afPayload = message.payload;
            if (typeof afPayload === "boolean") {
              state.autoFillEnabled = afPayload;
            } else if (afPayload && typeof afPayload === "object" && "enabled" in afPayload) {
              state.autoFillEnabled = afPayload.enabled ?? false;
            }
            sendResponse(getVideoStatus());
            break;
          }
          case "SELECT_VIDEO": {
            const selPayload = message.payload;
            const selIndex = typeof selPayload === "number" ? selPayload : selPayload && typeof selPayload === "object" && "index" in selPayload ? selPayload.index ?? 0 : -1;
            if (selIndex >= 0) {
              const videoArray = Array.from(state.videos);
              if (videoArray[selIndex]) {
                if (state.activeVideo) resetTransformation();
                state.activeVideo = videoArray[selIndex];
                observeVideo(state.activeVideo);
                state.gpuProcessor.attach(state.activeVideo);
                state.gpuProcessor.setEffects(state.sharpness, state.hdrBoost);
              }
            }
            sendResponse(getVideoStatus());
            break;
          }
          case "SAVE_SITE_SETTINGS": {
            const hostname = window.location.hostname;
            chrome.storage.local.get(["siteSettings"], (result) => {
              const siteSettings = result.siteSettings || {};
              siteSettings[hostname] = {
                hostname,
                enabled: true,
                settings: {
                  autoFill: state.autoFillEnabled,
                  adjustment: state.adjustment,
                  posX: state.posX,
                  posY: state.posY,
                  rotation: state.rotation,
                  mirrorH: state.mirrorH,
                  mirrorV: state.mirrorV,
                  cinemaCrop: state.cinemaCrop,
                  sharpness: state.sharpness,
                  hdrBoost: state.hdrBoost,
                  aspectRatio: state.aspectRatio
                }
              };
              chrome.storage.local.set({ siteSettings }, () => {
                sendResponse({ success: true, status: getVideoStatus() });
              });
            });
            return true;
          }
          case "RESET_SITE_SETTINGS": {
            const hostname = window.location.hostname;
            chrome.storage.local.get(["siteSettings"], (result) => {
              const siteSettings = result.siteSettings || {};
              delete siteSettings[hostname];
              chrome.storage.local.set({ siteSettings }, () => {
                sendResponse({ success: true, status: getVideoStatus() });
              });
            });
            return true;
          }
          default:
            sendResponse(null);
            break;
        }
      } catch (e) {
        console.error("[UWVF] Message handling error:", e);
        sendResponse(null);
      }
      return true;
    }
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      return handleInternalMessage(message, sendResponse);
    });
    window.addEventListener("message", (event) => {
      if (event.source !== window || !event.data || !event.data.__uwvf_test_req) return;
      const { id, type, payload } = event.data;
      handleInternalMessage({ type, payload }, (result) => {
        window.postMessage({ __uwvf_test_res: true, id, result }, "*");
      });
    });
    chrome.storage?.local?.get(["siteSettings", "globalSettings"], (result) => {
      if (!result) return;
      const hostname = window.location.hostname;
      const siteSetting = result.siteSettings?.[hostname];
      if (siteSetting?.settings) {
        if (siteSetting.settings.autoFill !== void 0) state.autoFillEnabled = siteSetting.settings.autoFill;
        if (siteSetting.settings.adjustment !== void 0) state.adjustment = siteSetting.settings.adjustment;
        if (siteSetting.settings.posX !== void 0) state.posX = siteSetting.settings.posX;
        if (siteSetting.settings.posY !== void 0) state.posY = siteSetting.settings.posY;
        if (siteSetting.settings.rotation !== void 0) state.rotation = siteSetting.settings.rotation;
        if (siteSetting.settings.mirrorH !== void 0) state.mirrorH = siteSetting.settings.mirrorH;
        if (siteSetting.settings.mirrorV !== void 0) state.mirrorV = siteSetting.settings.mirrorV;
        if (siteSetting.settings.cinemaCrop !== void 0) state.cinemaCrop = siteSetting.settings.cinemaCrop;
        if (siteSetting.settings.sharpness !== void 0) state.sharpness = siteSetting.settings.sharpness;
        if (siteSetting.settings.hdrBoost !== void 0) state.hdrBoost = siteSetting.settings.hdrBoost;
        if (siteSetting.settings.aspectRatio !== void 0) state.aspectRatio = siteSetting.settings.aspectRatio;
      } else {
        if (result.globalSettings?.autoFillDefault !== void 0) {
          state.autoFillEnabled = result.globalSettings.autoFillDefault;
        }
        if (result.globalSettings?.defaultSharpness !== void 0) {
          state.sharpness = result.globalSettings.defaultSharpness;
        }
        if (result.globalSettings?.defaultHdrBoost !== void 0) {
          state.hdrBoost = result.globalSettings.defaultHdrBoost;
        }
        if (result.globalSettings?.defaultAspectRatio !== void 0) {
          state.aspectRatio = result.globalSettings.defaultAspectRatio;
        }
      }
      if (result.globalSettings?.brightness !== void 0) {
        state.brightness = result.globalSettings.brightness;
      }
      if (result.globalSettings?.defaultCinemaCrop && state.cinemaCrop === "off") {
        state.cinemaCrop = result.globalSettings.defaultCinemaCrop;
      }
      if (state.sharpness > 0 || state.hdrBoost > 0 || state.brightness !== 100) {
        state.gpuProcessor.setEffects(state.sharpness, state.hdrBoost, state.brightness);
      }
    });
    chrome.storage?.onChanged?.addListener((changes, areaName) => {
      if (areaName === "local" && changes.globalSettings?.newValue) {
        const newBright = changes.globalSettings.newValue.brightness;
        if (newBright !== void 0 && newBright !== state.brightness) {
          state.brightness = newBright;
          state.gpuProcessor.setBrightness(newBright);
        }
      }
    });
    setupObservers();
    setupSPASupport();
    console.log("[UWVF] Content script initialized");
  })();
})();
